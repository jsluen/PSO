
function fit=yao_func(p,problem)

[popsize D] = size(p);

switch problem

    case 1    % Sphere
        fit = sum(p.^2,2);
        
    case 2    % Schwefel 1.2
        fit = zeros(popsize,1);
        for j = 1:D
            fit = fit + sum(p(:, 1:j), 2).^2;
        end         
        
    case 3    % Schwefel 2.22
        fit=sum(abs(p), 2) + prod(abs(p), 2);

    case 4    % Rosenbrock    
        fit=100*sum((p(:,2:D)-(p(:,1:D-1)).^2).^2,2)+sum(1-(p(:,1:(D-1))).^2,2);
        
    case 5    % Step
        fit = sum( floor(p(:,1:D) + 0.5).^2, 2);       
               
    case 6    % Quartic
        fit = zeros(popsize,1);
        for i = 1:popsize
            for j = 1:D
                fit(i) = fit(i) + j*p(i,j)^4;
            end
            fit(i) = fit(i) + rand();
        end
        
    case 7    % Rastrigin  
        fit=sum(p(:, 1:D).^ 2 - 10 .* cos(2 .* pi .*p(:,1:D)) + 10, 2);           

    case 8    % Ackley
        fit = 20+exp(1)-20*exp(-0.2*(1/D*sum(p.^2,2)).^0.5)-exp(1/D*sum(cos(2*pi*p),2));
        
    case 9    % Griewank
        fit = sum(p.^2,2)/4000-prod(cos(p./(repmat(1:D,popsize,1)).^0.5),2)+1;        
          
    case 10   % Zakharov
        fit = zeros(popsize,1);
        for i = 1:popsize
            fit(i) = sum(p(i,:).^2)+(sum(i/2*p(i,:)))^2 + (sum(i/2*p(i,:)))^4;
        end

    case 11    % Weierstrass
        fit1 = 0; fit2 = 0;
        for k = 1:21
            for i = 1:D
                fit1 = fit1 + (0.5^(k-1))*cos(2*pi*(3^(k-1))*(p(:,i)+0.5));
            end
            fit2 = fit2 + (0.5^(k-1))*cos(2*pi*(3^(k-1))*0.5);
        end
        fit = fit1-D*fit2;

    case 12    % Penalized
        p_1=p(:,1:D-1);
        p_2=p(:,2:D);
        p_3=p;
        temp_1=find(p>5);
        temp_2=find(p<-5);
        temp_3=find(p>=-5&p<=5);
        p_3(temp_1)=100*(p(temp_1)-5).^4;
        p_3(temp_2)=100*(-p(temp_2)-5).^4;
        p_3(temp_3)=0;
        fit=0.1*((sin(pi*3*p(:,1))).^2+sum((p_1-1).^2.*(1+(sin(3*pi*p_2)).^2),2)+(p(:,D)-1).^2.*(1+(sin(2*pi*p(:,D))).^2))+sum(p_3,2);
   
    case 13    % Michalewicz
        fit = zeros(popsize,1);
        for i = 1:popsize
            fit(i) = -sum(sin(p(i,:)).*(sin(i*p(i,:).^2/pi)).^20);
        end 
              
end

end